import { Link, NavLink } from "react-router-dom";
import { useState } from "react";
import "../styles/Navbar.css";

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-logo" onClick={closeMenu}>
          Musa Tech Services
        </Link>

        <button
          className="navbar-toggle"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle navigation menu"
        >
          ☰
        </button>

        <nav className={menuOpen ? "navbar-links active" : "navbar-links"}>
          <NavLink to="/" onClick={closeMenu}>Home</NavLink>
          <NavLink to="/about" onClick={closeMenu}>About</NavLink>
          <NavLink to="/services" onClick={closeMenu}>Services</NavLink>
          <NavLink to="/booking" onClick={closeMenu}>Book Service</NavLink>
          <NavLink to="/tracking" onClick={closeMenu}>Track Delivery</NavLink>
          <NavLink to="/money-transfer" onClick={closeMenu}>Money Transfer</NavLink>
          <NavLink to="/contact" onClick={closeMenu}>Contact</NavLink>

          <NavLink
            to="/customer-login"
            className="navbar-login"
            onClick={closeMenu}
          >
            Customer Login
          </NavLink>
        </nav>
      </div>
    </header>
  );
}
