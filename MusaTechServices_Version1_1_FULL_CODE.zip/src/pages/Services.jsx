import { Link } from "react-router-dom";
import "../styles/Services.css";

const services = [
  ["📱","Phone & Computer Repair","Professional repair, diagnostics, software installation, hardware upgrades, virus removal, and maintenance."],
  ["💻","Website & Software Development","Business websites, e-commerce stores, booking systems, dashboards, mobile-friendly applications, and custom software."],
  ["🚚","Delivery Services","Fast parcel delivery, package collection, courier services, business deliveries, and real-time tracking."],
  ["💸","Money Transfer Assistance","Secure money transfer support, payment guidance, transaction assistance, and customer service."],
  ["🏠","Home & Cleaning Services","Housemaids, home cleaning, office cleaning, and professional domestic support services."],
  ["👷","Recruitment & Manpower","Connecting employers with skilled workers, recruitment solutions, and manpower support."],
  ["📊","Business Support","Business consultation, digital transformation, IT support, document assistance, and operational solutions."],
  ["🤖","AI & Smart Solutions","Upcoming AI-powered services including chatbots, automation, analytics, and smart business tools."]
];

export default function Services() {
  return (
    <main className="services-page">
      <section className="services-hero">
        <h1>Our Services</h1>
        <p>Musa Tech Services offers multiple professional services through one modern digital platform.</p>
      </section>
      <section className="services-grid">
        {services.map(([icon,title,description]) => (
          <div className="service-card" key={title}>
            <div className="service-icon">{icon}</div>
            <h2>{title}</h2>
            <p>{description}</p>
            <Link to="/booking" className="service-button">Book This Service</Link>
          </div>
        ))}
      </section>
      <section className="services-bottom">
        <h2>Need a Custom Service?</h2>
        <p>If you don't see the service you need, contact our team and we'll help you find the right solution.</p>
        <Link to="/contact" className="contact-button">Contact Us</Link>
      </section>
    </main>
  );
}
