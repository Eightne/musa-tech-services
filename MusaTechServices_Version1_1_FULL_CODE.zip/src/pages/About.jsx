import "../styles/About.css";

export default function About() {
  return (
    <main className="about-page">
      <section className="about-hero">
        <div className="about-hero-content">
          <span className="about-badge">About Musa Tech Services</span>
          <h1>Building Reliable Digital, Delivery & Business Solutions</h1>
          <p>Musa Tech Services is a multi-service platform created to support individuals, families, workers, and businesses with trusted technology, delivery, money transfer assistance, home services, recruitment, and business support.</p>
        </div>
      </section>
      <section className="about-intro">
        <div className="about-text">
          <h2>Who We Are</h2>
          <p>We are a customer-focused service company combining technology with practical everyday solutions. Our goal is to make services easier, faster, and more organized through digital systems, clear communication, and reliable support.</p>
          <p>From repairing devices and building websites to managing delivery requests, supporting transfer inquiries, and connecting customers to home or manpower services, Musa Tech Services is designed as one trusted place for many important needs.</p>
        </div>
        <div className="about-card">
          <h3>Our Promise</h3>
          <p>To serve customers with honesty, speed, professionalism, and technology-driven solutions that make life and business easier.</p>
        </div>
      </section>
      <section className="about-founder">
        <div>
          <h2>Founder Message</h2>
          <p>Musa Tech Services was started with a vision to connect people with reliable services through technology.</p>
          <p>Our long-term goal is to grow into a full digital service platform serving multiple countries with booking systems, delivery tracking, customer dashboards, admin tools, payments, wallets, analytics, and AI support.</p>
        </div>
      </section>
      <section className="about-mission-vision">
        <div className="mission-card"><h3>Our Mission</h3><p>To provide reliable technology, delivery, transfer, home, manpower, and business support services through one simple and trusted digital platform.</p></div>
        <div className="mission-card"><h3>Our Vision</h3><p>To become a leading multi-service digital company connecting customers, workers, businesses, and communities across Saudi Arabia, Uganda, and other international markets.</p></div>
      </section>
      <section className="about-values">
        <h2>Our Core Values</h2>
        <div className="values-grid">
          {["Trust","Speed","Innovation","Professionalism","Growth","Community"].map((v) => (
            <div key={v}><h3>{v}</h3><p>We serve with {v.toLowerCase()} and customer focus.</p></div>
          ))}
        </div>
      </section>
    </main>
  );
}
