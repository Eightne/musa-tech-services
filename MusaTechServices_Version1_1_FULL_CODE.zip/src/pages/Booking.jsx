import { useState } from "react";
import "../styles/Booking.css";

export default function Booking() {
  const [formData, setFormData] = useState({fullName:"",phone:"",whatsapp:"",email:"",country:"",city:"",serviceType:"",preferredDate:"",preferredTime:"",address:"",notes:""});
  const [submitted, setSubmitted] = useState(false);
  const services = ["Phone & Computer Repair","Website & Software Development","Delivery Services","Money Transfer Assistance","Home & Cleaning Services","Recruitment & Manpower","Business Support","AI & Smart Solutions","Other"];
  const countries = ["Saudi Arabia","Uganda","United Arab Emirates","Kenya","Other"];
  function handleChange(e){setFormData((p)=>({...p,[e.target.name]:e.target.value}));}
  function handleSubmit(e){e.preventDefault(); setSubmitted(true);}
  return (
    <main className="booking-page">
      <section className="booking-hero"><h1>Book a Service</h1><p>Fill in your details and our team will contact you to confirm your request.</p></section>
      <section className="booking-section">
        <form className="booking-form" onSubmit={handleSubmit}>
          <h2>Customer Information</h2>
          <div className="form-grid">
            <div className="form-group"><label>Full Name *</label><input name="fullName" value={formData.fullName} onChange={handleChange} required /></div>
            <div className="form-group"><label>Phone Number *</label><input type="tel" name="phone" value={formData.phone} onChange={handleChange} required /></div>
            <div className="form-group"><label>WhatsApp Number</label><input type="tel" name="whatsapp" value={formData.whatsapp} onChange={handleChange} /></div>
            <div className="form-group"><label>Email Address</label><input type="email" name="email" value={formData.email} onChange={handleChange} /></div>
          </div>
          <h2>Service Details</h2>
          <div className="form-grid">
            <div className="form-group"><label>Country *</label><select name="country" value={formData.country} onChange={handleChange} required><option value="">Select country</option>{countries.map(c=><option key={c}>{c}</option>)}</select></div>
            <div className="form-group"><label>City *</label><input name="city" value={formData.city} onChange={handleChange} required /></div>
            <div className="form-group"><label>Service Type *</label><select name="serviceType" value={formData.serviceType} onChange={handleChange} required><option value="">Select service</option>{services.map(s=><option key={s}>{s}</option>)}</select></div>
            <div className="form-group"><label>Preferred Date *</label><input type="date" name="preferredDate" value={formData.preferredDate} onChange={handleChange} required /></div>
            <div className="form-group"><label>Preferred Time</label><input type="time" name="preferredTime" value={formData.preferredTime} onChange={handleChange} /></div>
            <div className="form-group"><label>Upload Image / Document</label><input type="file" /></div>
          </div>
          <div className="form-group full"><label>Address / Location *</label><textarea name="address" value={formData.address} onChange={handleChange} required /></div>
          <div className="form-group full"><label>Additional Notes</label><textarea name="notes" value={formData.notes} onChange={handleChange} /></div>
          <button type="submit" className="booking-button">Submit Booking</button>
          {submitted && <div className="booking-success">Booking submitted successfully. Our team will contact you soon.</div>}
        </form>
        <aside className="booking-summary"><h3>Booking Summary</h3>{Object.entries({Name:formData.fullName,Phone:formData.phone,Country:formData.country,City:formData.city,Service:formData.serviceType,Date:formData.preferredDate,Time:formData.preferredTime}).map(([k,v])=><p key={k}><strong>{k}:</strong> {v || "Not selected"}</p>)}</aside>
      </section>
    </main>
  );
}
