import { Link } from "react-router-dom";
import "../styles/Footer.css";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-brand">
          <h2>Musa Tech Services</h2>
          <p>
            Technology, delivery, money transfer support, home services,
            recruitment, and business solutions.
          </p>
        </div>

        <div className="footer-links">
          <h3>Quick Links</h3>
          <Link to="/">Home</Link>
          <Link to="/about">About</Link>
          <Link to="/services">Services</Link>
          <Link to="/booking">Book Service</Link>
          <Link to="/contact">Contact</Link>
        </div>

        <div className="footer-links">
          <h3>Services</h3>
          <Link to="/tracking">Track Delivery</Link>
          <Link to="/money-transfer">Money Transfer</Link>
          <Link to="/customer-login">Customer Login</Link>
          <Link to="/register">Create Account</Link>
        </div>

        <div className="footer-contact">
          <h3>Contact</h3>
          <p>Saudi Arabia: +966 568 628 337</p>
          <p>Uganda: +256 704 745 290</p>
          <p>Email: support@musatechservices.uk</p>
        </div>
      </div>

      <div className="footer-bottom">
        <p>© {year} Musa Tech Services. All rights reserved.</p>
      </div>
    </footer>
  );
}
