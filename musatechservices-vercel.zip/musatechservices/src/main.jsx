import React from 'react';
import { createRoot } from 'react-dom/client';
import { Smartphone, Laptop, Globe2, Truck, Wallet, Users, Home, Building2, ShieldCheck, BarChart3, MessageCircle, MapPin, Mail, Phone, CheckCircle2, ArrowRight } from 'lucide-react';
import './styles.css';

const services = [
  { icon: Smartphone, title: 'Phone Repair', text: 'Screen, battery, charging, software and diagnostics for smartphones.' },
  { icon: Laptop, title: 'Computer Repair', text: 'Laptop and desktop repair, upgrades, data recovery and maintenance.' },
  { icon: Globe2, title: 'Web & Software', text: 'Modern websites, business systems, dashboards and custom software.' },
  { icon: Truck, title: 'Delivery Services', text: 'Fast local delivery, order handling, tracking and customer updates.' },
  { icon: Wallet, title: 'Money Transfers', text: 'Reliable transfer support between Saudi Arabia and East Africa.' },
  { icon: Users, title: 'Recruitment & Manpower', text: 'Staffing, manpower coordination and business support services.' },
  { icon: Home, title: 'Home Services', text: 'Housemaids, cleaning and trusted home support coordination.' },
  { icon: Building2, title: 'Business Support', text: 'Operations, administration, logistics and digital transformation support.' }
];

const phases = ['Customer portal', 'Admin dashboard', 'AI assistant', 'Booking system', 'Delivery tracking', 'Digital wallet', 'Payments', 'Analytics'];

function App() {
  return (
    <main>
      <header className="nav">
        <a className="brand" href="#home"><span>MT</span>Musa Tech Services</a>
        <nav>
          <a href="#services">Services</a>
          <a href="#platform">Platform</a>
          <a href="#contact">Contact</a>
        </nav>
      </header>

      <section id="home" className="hero">
        <div className="heroText">
          <p className="eyebrow">Musa Tech System Enterprise • Phase 230 Complete</p>
          <h1>Technology, delivery and business services from one trusted platform.</h1>
          <p className="lead">We help customers and businesses with repair services, websites, software, delivery, money transfer, recruitment, home services and operational support.</p>
          <div className="actions">
            <a className="btn primary" href="https://wa.me/966568628337">WhatsApp Saudi Arabia <ArrowRight size={18}/></a>
            <a className="btn" href="tel:+256704745290">Call Uganda</a>
          </div>
        </div>
        <div className="heroCard">
          <ShieldCheck size={42}/>
          <h2>Enterprise-ready launch</h2>
          <p>Built for booking, tracking, customer service, payments, reporting and future multi-country expansion.</p>
          <div className="stats"><b>230/230</b><span>Project phases completed</span></div>
        </div>
      </section>

      <section id="services" className="section">
        <p className="eyebrow">Our Services</p>
        <h2>Everything customers need, organized professionally.</h2>
        <div className="grid">
          {services.map(({icon: Icon, title, text}) => (
            <article className="card" key={title}>
              <Icon size={28}/>
              <h3>{title}</h3>
              <p>{text}</p>
            </article>
          ))}
        </div>
      </section>

      <section id="platform" className="section split">
        <div>
          <p className="eyebrow">Digital Platform</p>
          <h2>Musa Tech System Enterprise v10.0</h2>
          <p>The final website is structured for a full service portal, with room to connect real backend systems, payments, wallet accounts and live delivery tracking.</p>
          <ul className="checks">
            {phases.map(item => <li key={item}><CheckCircle2 size={20}/>{item}</li>)}
          </ul>
        </div>
        <div className="analytics">
          <BarChart3 size={50}/>
          <h3>Built for growth</h3>
          <p>Designed for Saudi Arabia, Uganda and future country expansion with scalable service categories and customer support channels.</p>
        </div>
      </section>

      <section id="contact" className="section contact">
        <p className="eyebrow">Contact</p>
        <h2>Start a booking or business request today.</h2>
        <div className="contactGrid">
          <a className="contactItem" href="https://wa.me/966568628337"><MessageCircle/> WhatsApp: +966 568 628 337</a>
          <a className="contactItem" href="tel:+256704745290"><Phone/> Uganda: +256 704 745 290</a>
          <a className="contactItem" href="mailto:info@musatechservices.com"><Mail/> info@musatechservices.com</a>
          <span className="contactItem"><MapPin/> Riyadh, Saudi Arabia • East Africa support</span>
        </div>
      </section>

      <footer>
        <b>Musa Tech Services</b>
        <span>© 2026 Musa Tech Services. All rights reserved.</span>
      </footer>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
