import { useState } from "react";
import "../styles/DeliveryTracking.css";

export default function DeliveryTracking() {
  const [trackingNumber,setTrackingNumber]=useState("");
  const [searched,setSearched]=useState(false);
  const deliveryData={trackingId:trackingNumber||"MTS-2026-001",status:"In Transit",customerName:"Customer",driverName:"Assigned Driver",driverPhone:"+966 568 628 337",pickup:"Riyadh Pickup Location",destination:"Customer Delivery Address",estimatedDelivery:"Today",packageType:"General Package"};
  const timeline=["Booking Received","Package Collected","In Transit","Out for Delivery","Delivered"];
  return <main className="tracking-page">
    <section className="tracking-hero"><h1>Track Your Delivery</h1><p>Enter your tracking number to check your delivery status and package progress.</p></section>
    <section className="tracking-search-section"><form className="tracking-form" onSubmit={(e)=>{e.preventDefault();setSearched(true)}}><input value={trackingNumber} onChange={(e)=>setTrackingNumber(e.target.value)} placeholder="Enter tracking number e.g. MTS-2026-001" required/><button>Track Package</button></form></section>
    {searched && <section className="tracking-results">
      <div className="tracking-card"><h2>Delivery Status</h2><div className="status-badge">{deliveryData.status}</div><div className="tracking-info-grid">{Object.entries(deliveryData).map(([k,v])=><p key={k}><strong>{k}:</strong> {v}</p>)}</div></div>
      <div className="tracking-card"><h2>Delivery Timeline</h2><div className="timeline">{timeline.map((step,i)=><div className={i<3?"timeline-item completed":"timeline-item"} key={step}><span></span><p>{step}</p></div>)}</div></div>
      <div className="tracking-card driver-card"><h2>Driver Information</h2><p><strong>Name:</strong> {deliveryData.driverName}</p><p><strong>Phone:</strong> {deliveryData.driverPhone}</p><a href={`tel:${deliveryData.driverPhone}`} className="driver-button">Call Driver</a><a href={`https://wa.me/${deliveryData.driverPhone.replace(/\D/g,"")}`} target="_blank" rel="noreferrer" className="driver-button whatsapp">WhatsApp Driver</a></div>
      <div className="tracking-card map-placeholder"><h2>Live Map</h2><p>Google Maps live tracking will be connected in a later backend phase.</p></div>
    </section>}
  </main>
}
