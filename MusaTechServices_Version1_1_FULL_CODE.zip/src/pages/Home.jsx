import { Link } from "react-router-dom";
import "../styles/Home.css";

export default function Home() {
  return (
    <main className="home-page">
      <section className="home-hero">
        <div className="home-hero-content">
          <span className="home-badge">Trusted Tech, Delivery & Business Services</span>

          <h1>Musa Tech Services</h1>

          <p>
            We provide reliable technology solutions, delivery services, money
            transfer support, home services, recruitment, and business support
            for customers in Saudi Arabia, Uganda, and beyond.
          </p>

          <div className="home-actions">
            <Link to="/booking" className="home-btn primary">
              Book a Service
            </Link>

            <Link to="/services" className="home-btn secondary">
              View Services
            </Link>
          </div>
        </div>
      </section>

      <section className="home-services">
        <h2>Our Main Services</h2>
        <p className="section-intro">
          One platform for technology, delivery, transfers, and business support.
        </p>

        <div className="service-grid">
          <div className="service-card">
            <h3>Phone & Computer Repair</h3>
            <p>Fast diagnostics, repair, upgrades, and technical support.</p>
          </div>

          <div className="service-card">
            <h3>Website & Software Development</h3>
            <p>Modern websites, dashboards, systems, and business platforms.</p>
          </div>

          <div className="service-card">
            <h3>Delivery Services</h3>
            <p>Local delivery, package handling, and customer tracking support.</p>
          </div>

          <div className="service-card">
            <h3>Money Transfer Support</h3>
            <p>Assistance for safe and convenient customer transfer requests.</p>
          </div>

          <div className="service-card">
            <h3>Home & Cleaning Services</h3>
            <p>Housemaids, cleaning support, and reliable home service booking.</p>
          </div>

          <div className="service-card">
            <h3>Recruitment & Manpower</h3>
            <p>Support for workers, employers, recruitment, and business needs.</p>
          </div>
        </div>
      </section>

      <section className="home-stats">
        <div>
          <h3>24/7</h3>
          <p>Customer Support</p>
        </div>

        <div>
          <h3>6+</h3>
          <p>Service Categories</p>
        </div>

        <div>
          <h3>2</h3>
          <p>Main Countries</p>
        </div>

        <div>
          <h3>100%</h3>
          <p>Customer Focused</p>
        </div>
      </section>

      <section className="home-cta">
        <h2>Ready to request a service?</h2>
        <p>
          Start with a booking and our team will contact you through phone or
          WhatsApp.
        </p>

        <Link to="/booking" className="home-btn primary">
          Start Booking
        </Link>
      </section>
    </main>
  );
}
